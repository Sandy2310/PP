package com.bean;

import java.util.Scanner;


import com.service.ValidationClass;

public class Bean 
{
private int accountNumber;
private String name;
private double balance;
private String phoneNumber;

Scanner sc=new Scanner(System.in);
public int getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(int accountNumber) {
	this.accountNumber = accountNumber;
}
public String getName() 
{
	return name;
}
public void setName(String name) 
{
	  if(ValidationClass.validateName(name))
	    {
	        this.name=name;
	    }
	    else
	    {
	        System.out.println("Enter correct name");
	        setName(sc.next());
	    }

}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public String getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	   if(ValidationClass.ValidateNumber(phoneNumber))
	    {
	    this.phoneNumber = phoneNumber;
	     }
	    else
	    {
	        System.out.println("Enter valid Number");
	        setPhoneNumber(sc.next());
	    }
}
@Override
public String toString() {
	return "Bean [accountNumber=" + accountNumber + ", name=" + name + ", balance=" + balance + ", phoneNumber="
			+ phoneNumber + "]";
}

}

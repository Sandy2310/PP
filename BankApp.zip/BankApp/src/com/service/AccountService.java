package com.service;

import java.util.ArrayList;
import java.util.List;

import com.bean.Bean;
import com.bean.Transaction;
import com.dao.AccountDao;

public class AccountService {

	AccountDao ad = new AccountDao();

	public boolean validateAccount(int acc) 
	{
		List<Bean> acntList = ad.returnData();	
		for (Bean bean : acntList) {
			if(acc==bean.getAccountNumber())
				return true;
					}
		return false;
	}
	
	public void createAccount(Bean bean)
	{
	
		ad.storeData(bean);
	}

	public double showBalance(int accountId)
	{
	
		List<Bean> accountList = ad.returnData();
		
		for (Bean account : accountList) 
		{
			if (accountId == account.getAccountNumber())
				return account.getBalance();
			
		}
		return 0;
	}

	public double depositAmount(int accountId1, double depositAmount) 
	{
		double val = 0;	
		
		List<Bean> accountList = ad.returnData();
		
		for (Bean account : accountList) 
		{
				Transaction ts= new Transaction();
			if (accountId1 == account.getAccountNumber()) 
			{
				ts.setAccountNumber(accountId1);
				ts.setCredit(depositAmount);
				ts.setDebit(0);
				val = account.getBalance() + depositAmount;
				account.setBalance(val);
				ts.setBal(val);
				ad.storeTransaction(ts);
				return val;
			}
		}
		return 0;
	}

	public double withdrawAmount(int accountId2, double withdrawAmount)
	{
		double val = 0;
	
		List<Bean> accountList = ad.returnData();
		
		for (Bean account : accountList) 
		{
				Transaction ts= new Transaction();
			if (accountId2 == account.getAccountNumber()) 
			{
				ts.setAccountNumber(accountId2);
				ts.setCredit(0);
				ts.setDebit(withdrawAmount);
				val = account.getBalance() - withdrawAmount;
				account.setBalance(val);
				ts.setBal(val);
				ad.storeTransaction(ts);
				return val;
			}
		}
		return 0;
	}
	

	public void cashTransfer(int source, int destination, double money) 
	{
		Transaction ts= new Transaction();
		List<Bean> accountList = ad.returnData();
		for (Bean account : accountList) 
		{
			
			if (source == account.getAccountNumber()) 
			{
				ts.setAccountNumber(source);
				ts.setCredit(0);
				ts.setDebit(money);
				account.setBalance( account.getBalance() - money);	
				ts.setBal(account.getBalance());
				ad.storeTransaction(ts);
			}
		}
		
		for (Bean account : accountList)
		{
			if (destination == account.getAccountNumber()) 
			{
				ts.setAccountNumber(destination);
				ts.setCredit(money);
				ts.setDebit(0);
				account.setBalance( account.getBalance() + money);	
				ts.setBal(account.getBalance());
				ad.storeTransaction(ts);			
			}
		}
		
	}
	
		public List<Transaction> getTransaction(int accountNumber)
		{
	        List<Transaction> transactiondet = ad.returnTransaction();
	        List<Transaction> transactionList1 = new ArrayList<>();
	        for (Transaction transaction : transactiondet) {
	            if (accountNumber == transaction.getAccountNumber())
	            {
	                transactionList1.add(transaction);
	            }
	        }
	        return transactionList1;
	    }
	

	}

